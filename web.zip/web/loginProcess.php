<?php
session_start();
if(isset($_POST['save']))
{
    extract($_POST);
    include 'dbconfig.php';
    $sql=mysqli_query($conn,"SELECT * FROM login where email='$email' and password='$pass'");
    $row  = mysqli_fetch_array($sql);
   
    if(is_array($row))
    {
        $locked=$row['locked'];
        //if locked
        if($locked==0)
        {

        
        $_SESSION["email"]=$row['email'];
        $_SESSION['userid']=$row['userid'];
        $userid=$row['userid'];
      

        $sql_user=mysqli_query($conn,"SELECT * FROM user where userid='$userid'");
        $row_user  = mysqli_fetch_array($sql_user);
        if(is_array($row_user))
        {
            $first_name=$row_user['first_name'];
            $last_name=$row_user['last_name'];
            $_SESSION['user_first_name']=$first_name;
            $_SESSION['user_last_name']=$last_name;

        }
        // $_SESSION['user_type']=$row['user_type'];
        $usertype=$row['user_type'];
        
        if( $usertype=="Student")
        {
            $_SESSION['user_type']="student";
        header("Location: student/index.php"); 
        }
        if( $usertype=="Admin")
        {
            $_SESSION['user_type']="admin";
            header("Location: admin/index.php"); 
        }
        if( $usertype=="Faculty")
        {
            $_SESSION['user_type']="faculty";
            header("Location: faculty/index.php"); 
        }
        if( $usertype=="Stats Office")
        {
            $_SESSION['user_type']="Stats Office";
            header("Location: stats_office/index.php"); 
        }
    }
    else
    {
        echo "Account is locked. Please contact Admin/ IT Department to unlock it";
    }
            
    }
    else
    {
        //get the number of attempts and increase by 1
        $sql_login=mysqli_query($conn,"SELECT * FROM login where email='$email' ");
        $row_login  = mysqli_fetch_array($sql_login);
        $attempts=$row_login['attempts']+1;
        //if attempts is more than 3 lock it
        if($attempts>=3){
            $locked=1;
        }
        else
        {
            $locked=0;
        }
        $sql_update_login = "UPDATE login SET  attempts='$attempts',locked='$locked' WHERE email='$email'";
        $res_update_login = mysqli_query($conn1, $sql_update_login) or die(mysqli_error($conn1));
       
        echo "Invalid Email ID/Password";
    }
}
?>