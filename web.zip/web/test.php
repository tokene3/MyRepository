<?php
$servername = "your_server_name";
$username = "your_username";
$password = "your_password";
$dbname = "your_db_name";

// Create connection

include 'dbconfig.php';
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM course WHERE RIGHT(courseid, 4) > 2000 AND RIGHT(courseid, 4) < 4000";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table><tr><th>Course ID</th><th>Course Name</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["courseid"]."</td><td>".$row["course_name"]."</td></tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
